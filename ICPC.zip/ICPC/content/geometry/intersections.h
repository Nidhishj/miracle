// Line and Segment Intersections
template<class T>
T crossProduct(Point<T> a, Point<T> b, Point<T> c) {
    return (b - a).cross(c - a);
}

// 1 if left, -1 if right, 0 if collinear
template<class T>
int orientation(Point<T> a, Point<T> b, Point<T> c) {
    T cp = crossProduct(a, b, c);
    return (cp > 0) - (cp < 0);
}

// Check if point p is on segment ab
template<class T>
bool onSegment(Point<T> a, Point<T> b, Point<T> p) {
    return orientation(a, b, p) == 0 && p.x >= min(a.x, b.x) && p.x <= max(a.x, b.x) && p.y >= min(a.y, b.y) && p.y <= max(a.y, b.y);
}

// Check if segment ab and cd intersect
template<class T>
bool segmentIntersect(Point<T> a, Point<T> b, Point<T> c, Point<T> d) {
    int o1 = orientation(a, b, c), o2 = orientation(a, b, d);
    int o3 = orientation(c, d, a), o4 = orientation(c, d, b);
    if (o1 != o2 && o3 != o4) return true;
    if (onSegment(a, b, c) || onSegment(a, b, d) || onSegment(c, d, a) || onSegment(c, d, b)) return true;
    return false;
}

// Line intersection
bool lineIntersection(Pd a, Pd b, Pd c, Pd d, Pd& res) {
    double cp = (b - a).cross(d - c);
    if (abs(cp) < 1e-9) return false; // Parallel
    double t = (c - a).cross(d - c) / cp;
    res = a + (b - a) * t;
    return true;
}
